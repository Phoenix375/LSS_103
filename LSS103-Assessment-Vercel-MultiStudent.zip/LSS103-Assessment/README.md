# LSS 103 Assessment Studio

A responsive, static examination-practice website for **LSS 103 – Resource Perception and Management**. It uses HTML, CSS and vanilla JavaScript; no backend, account system, build step or server-side database is required.

## Deploy on Vercel

This project is ready to deploy as a static site.

1. Extract the ZIP file.
2. Create a GitHub repository and upload the **contents of the `LSS103-Assessment` folder** (so `index.html`, `css/`, `js/`, `data/` and `vercel.json` are at the repository root).
3. Sign in at [Vercel](https://vercel.com/) and choose **Add New → Project**.
4. Import the GitHub repository.
5. Select **Other** as the Framework Preset. Leave the Build Command and Install Command empty. Set the Output Directory to `.` if Vercel asks for one.
6. Choose **Deploy**. Vercel will publish the site and provide an HTTPS URL.

There is no build command. Keep `vercel.json` in the project root. When updating the website later, push the changed files to the connected GitHub branch; Vercel will create a new deployment.

## Run locally

You can open `index.html` directly in a modern browser, but using a local static server is recommended for browser storage and file-upload behavior. For example, from the project folder run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Multi-student profiles

When the site opens, students see the profile screen.

- **Create a profile:** Enter a name or nickname. A PIN is optional; if used, it must be 4–8 digits.
- **Open a profile:** Choose the student's profile. A PIN-protected profile asks for its PIN before opening.
- **Switch profiles:** In the website header, choose **Switch profile**. The current profile's work is saved before returning to the profile selector.
- **Delete a profile:** Choose **Delete** beside a profile and confirm. The confirmation explains that the profile's saved answers, marks, scores and uploaded files will be deleted from this browser.
- **Rename:** Open the profile, edit the name on the Dashboard, and choose **Save name**. This updates the profile label.

### Privacy and storage limitations

Profiles are separate workspaces within the same browser profile on the same device. Each student's assessment data is stored under a separate browser-storage key, and uploaded handwritten files are stored with the matching profile ID in IndexedDB. A one-time migration moves the previous single-student record and its old uploaded files into an **Existing student** profile (using the old saved name when available).

The optional PIN is only a casual-access barrier. It is hashed before storage, but the application is entirely client-side: profile data and files are **not encrypted**, and this is not strong authentication or protection against someone technically inspecting browser storage. Do not use it for confidential or sensitive information. Students should use separate operating-system/browser accounts on a shared computer when stronger separation is needed.

Data is local to the browser and device. The one-time legacy migration can only read the previous site data when the updated version is served from the same browser origin (the same domain and protocol). If you are moving to a different Vercel domain, export the old complete JSON record before moving; browser storage cannot be read across origins. Data does not automatically sync to Vercel, another browser, or another device. Clearing browser site data, using private browsing, or resetting the browser can remove saved profiles and progress. Use **Export complete record (JSON)** regularly to keep a backup of each student's work. The JSON export includes that profile's uploaded files.

## Website sections

1. **Dashboard** — course overview, student name and progress.
2. **Objective Test** — 30 multiple-choice questions, four options each, 25-minute timer, free navigation and locked submitted answers. The score is revealed after completion.
3. **Theory Test** — 10 questions, typed responses, handwritten uploads, completion tracking and provisional self-marks.
4. **Review & Reports** — objective results, theory progress, self-marks, verified marks, previous objective attempts, JSON/CSV export and print-to-PDF.
5. **Solutions & Explanations** — confirmation gate followed by separate objective and theory solution sections.

All existing question and solution source files are retained: `data/questions.js` and `data/solutions.js`.

## Theory verification workflow

1. Complete typed answers and/or attach handwritten scans in the Theory Test.
2. Self-mark each answer against the marking points in Solutions and Explanations.
3. In Review & Reports, export the **complete JSON record** for the active profile.
4. Use the exported record for independent review.
5. Import the returned verified-marks JSON using **Import verified marks**. The imported marks are saved only to the currently open profile.

The import accepts `verifiedTheoryMarks` or `verifiedMarks` as the total theory score. It can also accept a `verifiedMarksByQuestion` object keyed by question ID.

## Project structure

```text
LSS103-Assessment/
├── index.html
├── README.md
├── vercel.json
├── css/
│   └── style.css
├── js/
│   └── app.js
└── data/
    ├── questions.js
    └── solutions.js
```
