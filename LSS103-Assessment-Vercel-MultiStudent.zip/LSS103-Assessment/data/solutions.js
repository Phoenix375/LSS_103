window.LSS103_SOLUTIONS = {
  "answers": [
    1,
    2,
    1,
    0,
    0,
    1,
    0,
    2,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    1,
    0,
    0,
    2,
    0,
    0,
    0,
    1,
    0,
    0,
    0,
    0,
    1,
    1
  ],
  "objective": [
    "Natural resources include land and everything that exists on or in it, including biotic and abiotic environments.",
    "In Geography, a property becomes a resource when humans exploit or use it to satisfy needs.",
    "Zimmermann described a resource as that upon which one relies for aid, support or supply, a means to attain ends, or the capacity to take advantage of opportunities or overcome difficulties.",
    "Resources are subjective because their value depends on human appraisal; functional because they perform a role in satisfying a want; and dynamic because needs, knowledge, technology and circumstances can change their usefulness.",
    "Past experiences, present outlook, values, frame of mind, social circumstances and expectations can influence perception.",
    "Resource perception is a person's subjective assessment of substances or opportunities in the environment in relation to satisfying needs.",
    "Olfactory perception is perception through the sense of smell, one of the sensory means listed in the lecture.",
    "The lecture attributes the phrase ‘Resources are not, they become’ to Zimmermann (1951).",
    "In the functional or operational theory, ‘MAN’ represents the cultural level, contrasted with ‘man’ at the creature level.",
    "Knowledge is an intangible resource lodged within individuals and used to appraise other resources; the lecture calls it the ‘Mother of all Resources’.",
    "Reserves are the proportion of a resource, especially minerals, that can be exploited under existing conditions and with available technology.",
    "Resources may be used up, degraded, damaged or lose value as needs, perceptions and technologies change.",
    "Resources are commonly classified according to their ability to renew or reproduce themselves at a rate meaningful to humans.",
    "Non-renewable resources form so slowly, over geological time, that their renewal is not meaningful within a human lifespan.",
    "Petroleum is a non-renewable resource consumed by use, along with natural gas and coal.",
    "Copper, iron and zinc are examples of recyclable non-renewable metallic minerals.",
    "Fossil fuels formed from organic matter buried and transformed over millions of years.",
    "The lecture associates oil with the remains of ancient marine organisms.",
    "Flow or renewable resources are renewed within a timespan relevant to human beings.",
    "Wind power is listed as a renewable flow resource.",
    "Renewable resources can be depleted when the rate of use exceeds the rate of replenishment, or through overfishing, overhunting, pollution and habitat destruction.",
    "Energy is the capacity to do work.",
    "Useful work is work directed toward a human objective.",
    "Electrical energy is versatile because it can be converted into heat, light, chemical, magnetic and mechanical energy.",
    "Animate energy functions in and through living organisms.",
    "An animal pulling a cart is an example of muscular energy.",
    "Inanimate energy is derived from non-living matter, especially fossil fuels and falling water.",
    "The lecture identifies sunlight used in photosynthesis as elementary energy.",
    "The phrase emphasises human mental abilities such as planning, inventing, discovering, coordinating and managing forces.",
    "The aim is to release humans from physical toil as much as possible without impairing physical fitness."
  ],
  "theory": [
    {
      "answer": "Natural resources refer to land and everything that exists on or in it. They include biotic and abiotic components of the environment. They support human survival and satisfy human wants. In Geography, a physical property such as minerals or natural vegetation becomes a resource when people are able to use or exploit it. For example, climate may be used as a resource for tourism.",
      "points": [
        "Defines natural resources as land and everything existing on/in it (2)",
        "Identifies biotic and abiotic environments (2)",
        "Explains human use, needs or satisfaction of wants (2)",
        "Explains that a property becomes a resource when exploited or used by humans (3)",
        "Relevant example, such as climate and tourism (1)"
      ]
    },
    {
      "answer": "Zimmermann explains a resource as that upon which one relies for aid, support or supply; a means to attain given ends; or the capacity to take advantage of opportunities or overcome difficulties. Resources are subjective because their value depends on human appraisal, functional because they perform a role in satisfying a want, and dynamic because their usefulness changes with human needs, knowledge, technology and circumstances.",
      "points": [
        "Explains Zimmermann's definition (3)",
        "Subjective: depends on human appraisal (2)",
        "Functional: performs a role in satisfying a want or attaining an end (2)",
        "Dynamic: changes with needs, knowledge, technology or circumstances (3)"
      ]
    },
    {
      "answer": "Resource perception is an individual's subjective assessment of substances or opportunities in the environment for satisfying needs. It may be influenced by everyday reference points, distinctive features, past experiences, values, frame of mind, social circumstances and expectations. Two people may therefore perceive the same feature differently.",
      "points": [
        "Defines resource perception as subjective assessment of environmental substances/opportunities for needs (3)",
        "Explains any four relevant influencing factors (up to 6)",
        "Clear explanation or relevant example (1)"
      ]
    },
    {
      "answer": "Resources can be created when changes in human perception or technology make an environmental material useful for a new purpose. They can lose value when needs, tastes or technology change and the material falls into disuse. Resources can also be used up, degraded or damaged through use and poor management. For example, overuse can reduce soil fertility or degrade forests.",
      "points": [
        "Creation through changed perception or technology (3)",
        "Loss of value when needs, tastes or technology change (2)",
        "Destruction/depletion through use, degradation or damage (3)",
        "Relevant example(s) (2)"
      ]
    },
    {
      "answer": "At the creature level, ‘man’ has natural wants and capacities and is subject to natural conditions and passive adaptation. At the cultural level, ‘MAN’ uses brainpower, tools, fire, shelter, cultivation, domestication and knowledge to adapt actively to the environment. Human ingenuity and accumulated knowledge help people develop resources rather than merely depend on what nature provides directly.",
      "points": [
        "‘man’ as creature level: natural wants/capacities and passive adaptation (3)",
        "‘MAN’ as cultural level: active adaptation through brainpower, tools, fire, shelter, cultivation or domestication (4)",
        "Explains role of knowledge/experience and ingenuity (2)",
        "Clear contrast (1)"
      ]
    },
    {
      "answer": "Reserves are the proportion of a resource, especially minerals, that can be exploited under existing conditions and with available technology. The resource base is the sum total of environmental components that could become resources if they could be extracted. For example, an exploitable part of a mineral deposit may be a reserve, while a forest area may form a timber resource base.",
      "points": [
        "Defines reserves accurately (4)",
        "Defines resource base accurately (4)",
        "Appropriate examples (2)"
      ]
    },
    {
      "answer": "Non-renewable resources are also called non-replenishable, fund, stock, inventory or inorganic resources. They formed over geological time and are renewed too slowly to be meaningful within a human lifespan. The three kinds are resources consumed by use, such as petroleum, gas and coal; theoretically recoverable resources, such as potash, phosphorus and sulphur; and recyclable resources, such as copper, iron and zinc.",
      "points": [
        "Defines non-renewable resources and geological timescale (2)",
        "Consumed-by-use resources and examples (2)",
        "Theoretically recoverable resources and examples (2)",
        "Recyclable resources and examples (2)",
        "Clear distinction (2)"
      ]
    },
    {
      "answer": "Renewable or flow resources are naturally renewed within a timespan relevant to human beings. Examples include air, water in place, forests, grasslands, animals, soil, solar radiation, wind and tidal energy. They can still be depleted if people use them faster than they are replenished. Overfishing, overhunting, pollution and habitat destruction can also reduce or destroy them.",
      "points": [
        "Defines renewable/flow resources using relevant renewal timescale (3)",
        "Five appropriate examples (1 each, maximum 5)",
        "Explains depletion through overuse or environmental damage (2)"
      ]
    },
    {
      "answer": "Energy is the capacity to do work. Animate energy functions in and through living organisms, including muscular energy used by animals to pull carts or lift loads, and biotic energy associated with life and growth. Inanimate energy is derived from non-living matter, especially fossil fuels and falling water.",
      "points": [
        "Defines energy as capacity to do work (2)",
        "Defines animate energy (3)",
        "Gives relevant animate examples (2)",
        "Defines inanimate energy (2)",
        "Gives relevant inanimate example (1)"
      ]
    },
    {
      "answer": "The statement means that human beings' greatest contribution is not simply physical strength but their mental abilities. Brainpower enables people to plan, invent, discover, coordinate and manage forces and energy towards useful objectives. Knowledge and experience help people develop and use resources more effectively. The lecture also explains that energy use should release humans from physical toil without harming physical fitness, allowing specialisation.",
      "points": [
        "Explains the phrase as brainpower rather than physical strength (2)",
        "Discusses planning, inventing, discovering and aspiring (3)",
        "Explains coordinating/directing/managing forces and energy (2)",
        "Connects knowledge and ingenuity to resource development (2)",
        "Mentions reducing physical toil while preserving fitness/specialisation (1)"
      ]
    }
  ]
};
